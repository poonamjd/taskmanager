var name = 'Amarjeet singh';

document.write('Hello ' + name + '!');